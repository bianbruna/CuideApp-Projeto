package com.example.aluno.cuide.Activity;

import android.arch.lifecycle.HolderFragment;
import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.aluno.cuide.Entidades.Cuidador;
import com.example.aluno.cuide.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class ListarAdapter extends RecyclerView.Adapter<ListarAdapter.MyViewHolder> {

    Context context;
    ArrayList<Cuidador> cuidadors;

    public ListarAdapter(Context c, ArrayList<Cuidador> cuidadores){
            context = c;
            cuidadors = cuidadores;

    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.cardview,parent, false)) ;


    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        holder.name.setText(cuidadors.get(position).getNome());
        holder.email.setText(cuidadors.get(position).getEmail());
        holder.telefone.setText(cuidadors.get(position).getTelefone());
        holder.especialidade.setText(cuidadors.get(position).getTipoCuidado());
        holder.horarios.setText(cuidadors.get(position).getHorarioDisponive());
        Picasso.get().load(cuidadors.get(position).getImageUrl()).into(holder.profilePic);
        holder.onClick(position);

    }

    @Override
    public int getItemCount() {
        return cuidadors.size();

    }

    class MyViewHolder extends RecyclerView.ViewHolder{

        TextView name, email, telefone, horarios,especialidade;
        ImageView profilePic;
        Button btn;

        public MyViewHolder(View itemView) {
            super(itemView);
            name = (TextView) itemView.findViewById(R.id.name);
            email = (TextView) itemView.findViewById(R.id.emailList);
            telefone = (TextView) itemView.findViewById(R.id.telefoneList);
            especialidade = (TextView) itemView.findViewById(R.id.especialidadeList);
            horarios = (TextView) itemView.findViewById(R.id.horariosList);
            profilePic = (ImageView) itemView.findViewById(R.id.profilePic);
            btn = (Button) itemView.findViewById(R.id.checar);




        }

        public void onClick(final int position) {
            btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Toast.makeText(context, "Cuidador foi contratado em um período de 1 ano.", Toast.LENGTH_SHORT).show();


                }
            });


        }
    }

}
