package com.example.aluno.cuide.Activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.aluno.cuide.DAO.ConfiguraFirebase;
import com.example.aluno.cuide.Entidades.Cuidador;
import com.example.aluno.cuide.Entidades.Tutor;
import com.example.aluno.cuide.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;


public class Introducao extends AppCompatActivity {

    Button confirmar;
    EditText email;
    EditText senha;
    TextView telaTutor;
    TextView telaCuidador;
    List<Tutor> listTutor;
    private FirebaseAuth autenticacao;
    private DatabaseReference referenceDatabase;
    private FirebaseDatabase bd;
    private Tutor tutor ;
    private Cuidador cuidador;

    private String numId;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_introducao);
        getSupportActionBar().hide();

        confirmar = (Button) findViewById(R.id.entrarButton);
        email = (EditText) findViewById(R.id.emailTxt);
        senha =  (EditText) findViewById(R.id.senhaTxt);
        telaTutor = (TextView) findViewById(R.id.tutorCadastro);
        telaCuidador = (TextView) findViewById(R.id.cuidadorCadastro);
        listTutor = new ArrayList<>();
        inicializarFirebase();
        pesquisarTutores();

        confirmar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!email.getText().toString().equals("") && !senha.getText().toString().equals("")){
                        tutor = new Tutor();
                        tutor.setEmail(email.getText().toString());
                        tutor.setSenha(senha.getText().toString());
                        validarLogin();
                }else{

                    Toast.makeText(Introducao.this,"preencha os campos de e-mail e senha", Toast.LENGTH_SHORT).show();

                }
            }
        });

        telaTutor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrirCadastroTutor();
            }
        });

        telaCuidador.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrirCadastroCuidador();
            }
        });


    }

    private void inicializarFirebase() {
        bd = FirebaseDatabase.getInstance("https://cuide-31625.firebaseio.com/");
        referenceDatabase = bd.getReference();
    }

    private void pesquisarTutores(){
        Query q = referenceDatabase.child("tutores").orderByChild("nome");
        listTutor.clear();

        q.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot objSnapShot : dataSnapshot.getChildren()){
                    Tutor tutor = objSnapShot.getValue(Tutor.class);
                    listTutor.add(tutor);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void validarLogin() {
        autenticacao = ConfiguraFirebase.getFirebaseAutenticacao();
        autenticacao.signInWithEmailAndPassword(tutor.getEmail(), tutor.getSenha()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {

                if (task.isSuccessful()) {

                    for(int i = 0; i < listTutor.size();i++){
                        if(tutor.getEmail().equals(listTutor.get(i).getEmail())){
                            SharedPreferences dadosSessao = getSharedPreferences("dadosSessao", getBaseContext().MODE_PRIVATE);
                            SharedPreferences.Editor sessao = dadosSessao.edit();

                            sessao.putString("nome", listTutor.get(i).getNome());
                            sessao.putString("id", listTutor.get(i).getId());

                            sessao.commit();
                        }
                    }
                    abrirFeed();
                    Toast.makeText(Introducao.this, "Login efetuado com sucesso", Toast.LENGTH_SHORT).show();


                } else {

                    Toast.makeText(Introducao.this, "Não foi possível efetuar o login. Verifique seu Email e sua senha.", Toast.LENGTH_SHORT).show();

                }


            }
        });

    }
    private void validarLoginCuidador(){
        autenticacao = ConfiguraFirebase.getFirebaseAutenticacao();
        autenticacao.signInWithEmailAndPassword(cuidador.getEmail(), cuidador.getSenha()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {


                if (task.isSuccessful()) {
                    abrirFeedCuidador();
                    Toast.makeText(Introducao.this, "Login efetuado com sucesso", Toast.LENGTH_SHORT).show();


                } else {

                    Toast.makeText(Introducao.this, "Não foi possível efetuar o login.", Toast.LENGTH_SHORT).show();

                }


            }
        });


    }




    public void abrirFeed(){
        Intent abrirFedd;

        abrirFedd = new Intent(Introducao.this, TelaTutor.class);
        startActivity(abrirFedd);


    }

    public void abrirFeedCuidador(){

        Intent abrirFeddCuidadir;

        abrirFeddCuidadir = new Intent(Introducao.this,TelaTutor.class);
        startActivity(abrirFeddCuidadir);
    }

    public void abrirCadastroTutor(){
        Intent abrirCadastroT;

        abrirCadastroT = new Intent(Introducao.this,CadastrarActivity.class);
        startActivity(abrirCadastroT);


    }


    public void abrirCadastroCuidador(){
        Intent abrirCadastroC;

        abrirCadastroC = new Intent(Introducao.this,CadastrarCuidadorActivity.class);
        startActivity(abrirCadastroC);


    }
}


