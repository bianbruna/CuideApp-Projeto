package com.example.aluno.cuide.Activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


import com.example.aluno.cuide.R;

public class MainActivity extends AppCompatActivity {

    Button botao;
    Button bot2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        botao = (Button) findViewById(R.id.tutorBtn);
        bot2 = (Button) findViewById(R.id.loginBtn);

        botao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent abrirCadastro1 = new Intent(MainActivity.this, CadastrarActivity.class);
                startActivity(abrirCadastro1);
            }
        });

        bot2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent abrirLogin = new Intent(MainActivity.this, TelaTutor.class);
                startActivity(abrirLogin);
            }
        });

    }
}
