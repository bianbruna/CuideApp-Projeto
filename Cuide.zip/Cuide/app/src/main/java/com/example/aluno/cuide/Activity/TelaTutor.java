package com.example.aluno.cuide.Activity;

import android.animation.Animator;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.animation.LinearOutSlowInInterpolator;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.OvershootInterpolator;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import com.aurelhubert.ahbottomnavigation.AHBottomNavigation;
import com.aurelhubert.ahbottomnavigation.AHBottomNavigationItem;
import com.aurelhubert.ahbottomnavigation.AHBottomNavigationViewPager;
import com.example.aluno.cuide.Entidades.Tutor;
import com.example.aluno.cuide.R;
import com.gigamole.infinitecycleviewpager.HorizontalInfiniteCycleViewPager;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

public class TelaTutor extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private DrawerLayout nDrawerLayout;
    private ActionBarDrawerToggle aToggle;
    private TextView txtNome;
    private ImageView fotoPerfil;
    List<Tutor> listTutor;

    private android.app.Fragment currentFragment;
    private Fragment1 fragment1 = new Fragment1();
    private Fragment2 fragment2 = new Fragment2();
    private Fragment3 fragment3 = new Fragment3();

    private BottomViewPagerAdapter bottomViewPagerAdapter;
    private ArrayList<AHBottomNavigationItem> bottomNavigationItems = new ArrayList<>();

    // UI
    private AHBottomNavigationViewPager viewPagerBottom;
    private AHBottomNavigation bottomNavigation;
    private FloatingActionButton floatingActionButton;


    private Toolbar nToolbar;
    private DatabaseReference referenceDatabase;
    private FirebaseDatabase bd;

    List<Integer> lstImages = new ArrayList<>();

    ImageView image;

    SharedPreferences sessao;
    SharedPreferences.Editor finalizarSessao;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        inicializarFirebase();

        initData();
        sessao = getSharedPreferences("dadosSessao", getBaseContext().MODE_PRIVATE);
        finalizarSessao = sessao.edit();

        HorizontalInfiniteCycleViewPager pager = (HorizontalInfiniteCycleViewPager) findViewById(R.id.horizontal_cycle);
        MyAdapter adapter= new MyAdapter(lstImages,getBaseContext());
        pager.setAdapter(adapter);
        listTutor = new ArrayList<>();
        nDrawerLayout = (DrawerLayout) findViewById(R.id.drawlayout);
        aToggle = new ActionBarDrawerToggle(this, nDrawerLayout, R.string.open, R.string.close);
        image = (ImageView) findViewById(R.id.imageView);


        NavigationView navigationView = findViewById(R.id.nav_vius);
        navigationView.setNavigationItemSelectedListener(this);

        View v = navigationView.inflateHeaderView(R.layout.navigation_header);
        txtNome = (TextView) v.findViewById(R.id.nomeTxt_tela);
        txtNome.setText(sessao.getString("nome", "vazio"));
        fotoPerfil = (ImageView) v.findViewById(R.id.foto_perfil);

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                carregarFoto();
            }
        }, 1000);

        nDrawerLayout.addDrawerListener(aToggle);
        aToggle.syncState();

        initUI();




      /* if(savedInstanceState == null) {
           getSupportFragmentManager().beginTransaction().replace(R.id.drawlayout, new PerfilFragment()).commit();
           navigationView.setCheckedItem(R.id.nav_sair);
       }*/


        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }

    private void carregarFoto() {
        Query q = referenceDatabase.child("tutores").orderByChild("nome");
        listTutor.clear();

        q.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot objSnapShot : dataSnapshot.getChildren()){
                    Tutor tutor = objSnapShot.getValue(Tutor.class);
                    listTutor.add(tutor);
                }

                for(int i=0; i<listTutor.size();i++){
                    if(listTutor.get(i).getId().equals(sessao.getString("id", "vazio"))){
                        Picasso.get().load(listTutor.get(i).getImageUrl()).fit().into(fotoPerfil);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }


    public boolean onOptionsItemSelected(MenuItem item){

        if(aToggle.onOptionsItemSelected(item)){
            return true;
        }

        return super.onOptionsItemSelected(item);

    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
         switch (item.getItemId()){
             case R.id.nav_perfil:

                 Toast.makeText(TelaTutor.this, "Testando Listener", Toast.LENGTH_SHORT).show();
                 break;

             case R.id.nav_sobre:
                 Intent intent = new Intent(TelaTutor.this, SobreActivity.class);
                 startActivity(intent);
                 finish();
                 break;
             case R.id.nav_sair:
                 getSupportFragmentManager().beginTransaction().replace(R.id.horizontal_cycle,
                         new SobreFragment()).commit();

                 break;



         }
        nDrawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    private void openFragment(Fragment fragment) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.horizontal_cycle, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }


    public void chamarLogin(){
        Intent intent = new Intent(TelaTutor.this, Introducao.class);
        startActivity(intent);
        finish();


    }

    private void initData(){
        lstImages.add(R.drawable.cardnotification);
        lstImages.add(R.drawable.cardchat);
        lstImages.add(R.drawable.cardsearch);




    }


    private void initUI() {

        bottomNavigation = (AHBottomNavigation) findViewById(R.id.bottom_navigation);
        viewPagerBottom = (AHBottomNavigationViewPager) findViewById(R.id.view_pager_bottom);
        floatingActionButton = (FloatingActionButton) findViewById(R.id.floating_action_button);

        //Aqui onde é adicionado os fragments no bottom
        viewPagerBottom.setOffscreenPageLimit(2);
        bottomViewPagerAdapter = new BottomViewPagerAdapter(getSupportFragmentManager());
        bottomViewPagerAdapter.add(fragment1);
        bottomViewPagerAdapter.add(fragment2);
        bottomViewPagerAdapter.add(fragment3);
        viewPagerBottom.setAdapter(bottomViewPagerAdapter);

        currentFragment = bottomViewPagerAdapter.getCurrentFragment();


        AHBottomNavigationItem item1 = new AHBottomNavigationItem(R.string.tab_1, R.drawable.home, R.color.color_tab_1);
        AHBottomNavigationItem item2 = new AHBottomNavigationItem(R.string.tab_2, R.drawable.chat, R.color.color_tab_1);
        AHBottomNavigationItem item3 = new AHBottomNavigationItem(R.string.tab_3, R.drawable.search, R.color.color_tab_1);

        bottomNavigationItems.add(item1);
        bottomNavigationItems.add(item2);
        bottomNavigationItems.add(item3);

        bottomNavigation.addItems(bottomNavigationItems);


        bottomNavigation.setAccentColor(Color.parseColor("#2F4F4F"));
        bottomNavigation.setInactiveColor(Color.parseColor("#2E8B57"));
        bottomNavigation.setCurrentItem(0);

        bottomNavigation.setOnTabSelectedListener(new AHBottomNavigation.OnTabSelectedListener() {
            @Override




            public boolean onTabSelected(int position, boolean wasSelected) {

                if (currentFragment == null) {
                    currentFragment = bottomViewPagerAdapter.getCurrentFragment();
                }


                if (currentFragment != null) {
                    if (currentFragment instanceof Fragment1) {
                        fragment1.willBeHidden();

                    } else if (currentFragment instanceof Fragment2) {

                        fragment2.willBeHidden();

                    } else if (currentFragment instanceof Fragment3) {
                        Intent intent = new Intent(TelaTutor.this, PesquisarCuidadores.class);
                        finish();
                    }
                }

                //Aqui é onde é setado qual o fragment atual
                //Em seguida é pego o fragment atual e feito o fade dependendo de qual instancia for

                viewPagerBottom.setCurrentItem(position, false);
                currentFragment = bottomViewPagerAdapter.getCurrentFragment();

                if (currentFragment instanceof Fragment1) {

                    fragment1.willBeDisplayed();

                } else if (currentFragment instanceof Fragment2) {

                    fragment2.willBeDisplayed();

                } else if (currentFragment instanceof Fragment3) {
                    Intent intent = new Intent(TelaTutor.this, PesquisarCuidadores.class);
                    startActivity(intent);
                    finish();

                }


                if (position == 1) {
                    bottomNavigation.setNotification("", 1);
                    Intent intent = new Intent(TelaTutor.this, ChatActivity.class);
                    startActivity(intent);
                    finish();

                    /*floatingActionButton.setVisibility(View.VISIBLE);
                    floatingActionButton.setAlpha(0f);
                    floatingActionButton.setScaleX(0f);
                    floatingActionButton.setScaleY(0f);
                    floatingActionButton.animate()
                            .alpha(1)
                            .scaleX(1)
                            .scaleY(1)
                            .setDuration(300)
                            .setInterpolator(new OvershootInterpolator())
                            .setListener(new Animator.AnimatorListener() {
                                @Override
                                public void onAnimationStart(Animator animation) {

                                }

                                @Override
                                public void onAnimationEnd(Animator animation) {
                                    floatingActionButton.animate()
                                            .setInterpolator(new LinearOutSlowInInterpolator())
                                            .start();
                                }

                                @Override
                                public void onAnimationCancel(Animator animation) {

                                }

                                @Override
                                public void onAnimationRepeat(Animator animation) {

                                }
                            })
                            .start();

                } else {
                    if (floatingActionButton.getVisibility() == View.VISIBLE) {
                        floatingActionButton.animate()
                                .alpha(0)
                                .scaleX(0)
                                .scaleY(0)
                                .setDuration(300)
                                .setInterpolator(new LinearOutSlowInInterpolator())
                                .setListener(new Animator.AnimatorListener() {
                                    @Override
                                    public void onAnimationStart(Animator animation) {

                                    }

                                    @Override
                                    public void onAnimationEnd(Animator animation) {
                                        floatingActionButton.setVisibility(View.GONE);
                                    }

                                    @Override
                                    public void onAnimationCancel(Animator animation) {
                                        floatingActionButton.setVisibility(View.GONE);
                                    }

                                    @Override
                                    public void onAnimationRepeat(Animator animation) {

                                    }
                                })
                                .start();
                    }*/
                }


                if(position == 2){
                    bottomNavigation.setNotification("", 2);
                    Intent intent = new Intent(TelaTutor.this, PesquisarCuidadores.class);
                    startActivity(intent);
                    finish();


                }

                return true;
            }
        });

        bottomNavigation.setOnNavigationPositionListener(new AHBottomNavigation.OnNavigationPositionListener() {
            @Override
            public void onPositionChange(int y) {
                Log.d("DemoActivity", "BottomNavigation Position: " + y);
            }
        });




    }

    public void Listar(){
        Intent intent = new Intent(TelaTutor.this, PesquisarCuidadores.class);


    }

    private void inicializarFirebase() {
        bd = FirebaseDatabase.getInstance("https://cuide-31625.firebaseio.com/");
        referenceDatabase = bd.getReference();
    }



}
