package com.example.aluno.cuide.Activity;

import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.aluno.cuide.DAO.ConfiguraFirebase;
import com.example.aluno.cuide.Entidades.Cuidador;
import com.example.aluno.cuide.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

public class CadastrarCuidadorActivity extends AppCompatActivity {

    private static final int PICk_IMAGE_REQUEST = 1;

    Button botao;
    EditText nome;
    EditText email;
    EditText rg;
    EditText dataNasc;
    EditText telefone;
    EditText senha;
    EditText confirmarSenha;
    EditText tCuidado;
    EditText hDisponivel;
    EditText aExperiencia;
    Button mButtonChooseImage;
    ImageView mImageView;
    ProgressBar mProgressBar;

    Uri mImageUri;
    private Cuidador cuidador;

    private FirebaseAuth autenticacao ;
    private StorageReference mStorageRef;
    private DatabaseReference databaseCuidador;









    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastrar2);

        botao = (Button) findViewById(R.id.proxBtn);
        nome = (EditText) findViewById(R.id.nomeTxt) ;
        email =(EditText) findViewById(R.id.emailTxt) ;
        rg = (EditText) findViewById(R.id.rgTxt);
        dataNasc = (EditText) findViewById(R.id.nascimentoTxt) ;
        telefone = (EditText) findViewById(R.id.telefoneTxt);
        senha = (EditText) findViewById(R.id.senhaTxt);
        confirmarSenha = (EditText) findViewById(R.id.conSenhaTxt);
        tCuidado = (EditText) findViewById(R.id.tipoCuidado);
        hDisponivel = (EditText) findViewById(R.id.horario);
        aExperiencia = (EditText)findViewById(R.id.ano);
        mButtonChooseImage = (Button) findViewById(R.id.button_choose_image);
        mImageView = (ImageView) findViewById(R.id.image_view);
        mProgressBar =(ProgressBar) findViewById(R.id.progress_bar);


        mStorageRef = FirebaseStorage.getInstance().getReference("tutores");
        databaseCuidador = FirebaseDatabase.getInstance().getReference("cuidadores");

        mButtonChooseImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFileChooser();
            }
        });


        botao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(senha.getText().toString().equals(confirmarSenha.getText().toString())){
                    cuidador = new Cuidador();

                    cuidador.setNome(nome.getText().toString());
                    cuidador.setEmail(email.getText().toString());
                    cuidador.setRg(rg.getText().toString());
                    cuidador.setDatNasc(dataNasc.getText().toString());
                    cuidador.setTelefone(telefone.getText().toString());
                    cuidador.setRg(senha.getText().toString());
                    cuidador.setDatNasc(confirmarSenha.getText().toString());
                    cuidador.setTipoCuidado(tCuidado.getText().toString());
                    cuidador.setHorarioDisponive(hDisponivel.getText().toString());
                    cuidador.setAnoExperiencia(aExperiencia.getText().toString());






                    CadastrarTutor();
                }else{
                    Toast.makeText(CadastrarCuidadorActivity.this, "As senhas não correspondem", Toast.LENGTH_LONG).show();

                }


            }

        });



    }

    private void CadastrarTutor(){
        String id = databaseCuidador.push().getKey();
        String smImageUrl,snome, semail, srg, sdataNasc, stelefone, ssenha, stipoCuidado, shDisponivel,saExperiencia;
        Cuidador cuidador = new Cuidador();
        snome = nome.getText().toString();
        semail = email.getText().toString();
        srg = rg.getText().toString();
        sdataNasc = dataNasc.getText().toString();
        stelefone = telefone.getText().toString();
        ssenha = senha.getText().toString();
        stipoCuidado = tCuidado.getText().toString();
        shDisponivel = hDisponivel.getText().toString();
        saExperiencia = aExperiencia.getText().toString();
        smImageUrl = mImageUri.toString();



        cuidador.setId(id);
        cuidador.setNome(snome);
        cuidador.setEmail(semail);
        cuidador.setRg(srg);
        cuidador.setDatNasc(sdataNasc);
        cuidador.setTelefone(stelefone);
        cuidador.setSenha(ssenha);
        cuidador.setTipoCuidado(stipoCuidado);
        cuidador.setHorarioDisponive(shDisponivel);
        cuidador.setAnoExperiencia(saExperiencia);
        cuidador.setImageUrl(smImageUrl);


        databaseCuidador.child(id).setValue(cuidador);
        autenticacao = ConfiguraFirebase.getFirebaseAutenticacao();
        autenticacao.createUserWithEmailAndPassword(
                cuidador.getEmail(), cuidador.getSenha()).addOnCompleteListener(CadastrarCuidadorActivity.this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    Toast.makeText(CadastrarCuidadorActivity.this, "Usuário cadastrado com sucesso.", Toast.LENGTH_LONG).show();

                    chamarLogin();

                }else{
                    String erroExcecao = "";

                    try{
                        throw task.getException();

                    }catch (FirebaseAuthWeakPasswordException e){
                        erroExcecao="Digite uma senha mais forte contendo no minimo 8 carac";
                    }catch (FirebaseAuthInvalidCredentialsException e){
                        erroExcecao="O email digitado está invalido";
                    }catch (FirebaseAuthUserCollisionException e){
                        erroExcecao="Email já cadastrado no Cuide";

                    }catch (Exception e){
                        erroExcecao = "Erro ao efetuar Cadastro, tente novamente";
                        e.printStackTrace();
                    }
                    Toast.makeText(CadastrarCuidadorActivity.this, "Erro " + erroExcecao, Toast.LENGTH_LONG).show();

                }
            }
        });


        if (mImageUri != null){

            StorageReference fileReference = mStorageRef.child(System.currentTimeMillis() + "." + getFileExtension(mImageUri));

            fileReference.putFile(mImageUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            mProgressBar.setProgress(0);
                        }
                    }, 500);

                    Toast.makeText(CadastrarCuidadorActivity.this,"Foto salva com sucesso", Toast.LENGTH_LONG).show();


                }
            })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(CadastrarCuidadorActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                            double progress = (100.0 * taskSnapshot.getBytesTransferred()/taskSnapshot.getTotalByteCount());
                            mProgressBar.setProgress((int) progress);
                        }
                    });



        } else{
            Toast.makeText(this, "Nenhum arquivo selacionado", Toast.LENGTH_SHORT).show();

        }
    }

    public void chamarLogin(){
        Intent intent = new Intent(CadastrarCuidadorActivity.this, Introducao.class);
        startActivity(intent);
        finish();


    }



    public void chamarInserirFoto(){
        Intent intent = new Intent(CadastrarCuidadorActivity.this, Introducao.class);
        startActivity(intent);
        finish();


    }

    private void openFileChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, PICk_IMAGE_REQUEST);


    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == PICk_IMAGE_REQUEST && resultCode == RESULT_OK && data != null
                && data.getData() != null){

            mImageUri = data.getData();

            Picasso.get().load(mImageUri).into(mImageView);





        }
    }

    private String getFileExtension(Uri uri){
        ContentResolver cR = getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton().getSingleton();
        return mime.getExtensionFromMimeType(cR.getType(uri));
    }

    private void uploadFile(){
        if (mImageUri != null){

            StorageReference fileReference = mStorageRef.child(System.currentTimeMillis() + "." + getFileExtension(mImageUri));

            fileReference.putFile(mImageUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            mProgressBar.setProgress(0);
                        }
                    }, 500);

                    Toast.makeText(CadastrarCuidadorActivity.this,"Foto salva com sucesso", Toast.LENGTH_LONG).show();
                    String uploadId = databaseCuidador.push().getKey();
                    databaseCuidador.child(uploadId);

                }
            })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(CadastrarCuidadorActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                            double progress = (100.0 * taskSnapshot.getBytesTransferred()/taskSnapshot.getTotalByteCount());
                            mProgressBar.setProgress((int) progress);
                        }
                    });



        } else{
            Toast.makeText(this, "Nenhum arquivo selacionado", Toast.LENGTH_SHORT).show();

        }



    }


}