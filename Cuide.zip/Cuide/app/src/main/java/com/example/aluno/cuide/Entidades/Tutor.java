package com.example.aluno.cuide.Entidades;


import com.example.aluno.cuide.DAO.ConfiguraFirebase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.Exclude;

import java.util.HashMap;
import java.util.Map;

    public class Tutor {
        String id;
        String mImageUrl;
        String nome;
        String email;
        String rg;
        String datNasc;
        String telefone;
        String senha;
        String nomeDependente;
        String dataNascDependente;
        String tipo;
        String rua;
        String complemento;
        String cep;
        String cidade;
        String especialidade;
        String identificador = "1";




        public Tutor() {
        }

        public Tutor(String imageUrl){
            mImageUrl = imageUrl;

        }
        public String getNome() {
            return nome;
        }

        public String getEmail() {
            return email;
        }

        public String getRg() {
            return rg;
        }

        public String getDatNasc() {
            return datNasc;
        }

        public String getTelefone() {
            return telefone;
        }



        public String getSenha() {
            return senha;
        }

        public String getId() {
            return id;
        }

        public String getNomeDependente() {
            return nomeDependente;
        }

        public String getDataNascDependente() {
            return dataNascDependente;
        }

        public String getTipo() {
            return tipo;
        }

        public String getRua() {
            return rua;
        }

        public String getComplemento() {
            return complemento;
        }

        public String getCep() {
            return cep;
        }

        public String getCidade() {
            return cidade;
        }

        public String getIdentificador() {
            return identificador;
        }

        public void setId(String id) {
            this.id = id;
        }

        public void setNome(String nome) {
            this.nome = nome;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public void setRg(String rg) {
            this.rg = rg;
        }

        public void setDatNasc(String datNasc) {
            this.datNasc = datNasc;
        }

        public void setTelefone(String telefone) {
            this.telefone = telefone;
        }

        public void setSenha(String senha) {
            this.senha = senha;
        }


        public void setNomeDependente(String nomeDependente) {
            this.nomeDependente = nomeDependente;
        }

        public void setDataNascDependente(String dataNascDependente) {
            this.dataNascDependente = dataNascDependente;
        }

        public void setTipo(String tipo) {
            this.tipo = tipo;
        }

        public void setRua(String rua) {
            this.rua = rua;
        }

        public void setComplemento(String complemento) {
            this.complemento = complemento;
        }

        public void setCep(String cep) {
            this.cep = cep;
        }

        public void setCidade(String cidade) {
            this.cidade = cidade;
        }

        public void setIdentificador(String identificador) {
            this.identificador = identificador;
        }

        public String getEspecialidade() {
            return especialidade;
        }

        public void setEspecialidade(String especialidade) {
            this.especialidade = especialidade;
        }

        public String getImageUrl() {
            return mImageUrl;
        }

        public void setImageUrl(String imageUrl) {
            mImageUrl = imageUrl;
        }




    }
