package com.example.aluno.cuide.Entidades;

public class Cuidador {
    String id;
    String nome;
    String email;
    String mImageUrl;
    String rg;
    String datNasc;
    String telefone;
    String celular;
    String senha;
    String confirmarSenha;
    String tipoCuidado;
    String horarioDisponive;
    String anoExperiencia;
    String identificador="2";
    Boolean permission;

    public Cuidador() {
    }

    public String getNome() {
        return nome;
    }

    public String getEmail() {
        return email;
    }

    public String getRg() {
        return rg;
    }

    public String getDatNasc() {
        return datNasc;
    }

    public String getTelefone() {
        return telefone;
    }

    public String getCelular() {
        return celular;
    }

    public String getSenha() {
        return senha;
    }

    public String getConfirmarSenha() {
        return confirmarSenha;
    }

    public String getTipoCuidado() {
        return tipoCuidado;
    }

    public String getHorarioDisponive() {
        return horarioDisponive;
    }

    public String getAnoExperiencia() {
        return anoExperiencia;
    }

    public String getId() {
        return id;
    }

    public String getIdentificador() {
        return identificador;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public void setDatNasc(String datNasc) {
        this.datNasc = datNasc;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public void setConfirmarSenha(String confirmarSenha) {
        this.confirmarSenha = confirmarSenha;
    }

    public void setTipoCuidado(String tipoCuidado) {
        this.tipoCuidado = tipoCuidado;
    }

    public void setHorarioDisponive(String horarioDisponive) {
        this.horarioDisponive = horarioDisponive;
    }

    public void setAnoExperiencia(String anoExperiencia) {
        this.anoExperiencia = anoExperiencia;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setIdentificador(String identificador) {
        this.identificador = identificador;
    }

    public Boolean getPermission() {
        return permission;
    }

    public void setPermission(Boolean permission) {
        this.permission = permission;
    }

    public String getImageUrl() {
        return mImageUrl;
    }

    public void setImageUrl(String imageUrl) {
        mImageUrl = imageUrl;
    }

}
