package com.example.aluno.cuide.Activity;

public class Profile {
    private String name;


}
