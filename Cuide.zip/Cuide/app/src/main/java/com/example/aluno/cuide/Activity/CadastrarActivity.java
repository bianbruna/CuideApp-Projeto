package com.example.aluno.cuide.Activity;

import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.aluno.cuide.DAO.ConfiguraFirebase;
import com.example.aluno.cuide.Entidades.Tutor;
import com.example.aluno.cuide.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

public class CadastrarActivity extends AppCompatActivity {

    private static final int PICk_IMAGE_REQUEST = 1;

    Button botao;
    EditText nome;
    EditText email;
    EditText rg;
    EditText dataNasc;
    EditText telefone;
    EditText senha;
    EditText confirmarSenha;
    EditText nomePaciente;
    EditText dataNascPaciente;
    EditText tipoCuidado;
    EditText ruaTxt;
    EditText complementoTxt;
    EditText cepTxt;
    EditText cidadeTxt;
    Button mButtonChooseImage;
    ImageView mImageView;
    ProgressBar mProgressBar;

    Uri mImageUri;
    private Tutor tutor;

    private FirebaseAuth autenticacao;
    private StorageReference mStorageRef;
    private DatabaseReference databaseTutor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastrar);



        botao = (Button) findViewById(R.id.proxBtn);

        nome = (EditText) findViewById(R.id.nomeTxt) ;
        email =(EditText) findViewById(R.id.emailTxt) ;
        rg = (EditText) findViewById(R.id.rgTxt);
        dataNasc = (EditText) findViewById(R.id.nascimentoTxt) ;
        telefone = (EditText) findViewById(R.id.telefoneTxt);
        senha = (EditText) findViewById(R.id.senhaTxt);
        confirmarSenha = (EditText) findViewById(R.id.conSenhaTxt);
        nomePaciente = findViewById(R.id.nomePaciente)  ;
        dataNascPaciente = findViewById(R.id.datanascimento) ;
        tipoCuidado= findViewById(R.id.tipo);
        ruaTxt = findViewById(R.id.rua);
        complementoTxt =findViewById(R.id.complemento) ;
        cepTxt = findViewById(R.id.cep) ;
        cidadeTxt = findViewById(R.id.cidade);
        mButtonChooseImage = (Button) findViewById(R.id.button_choose_image);
        mImageView = (ImageView) findViewById(R.id.image_view);
        mProgressBar =(ProgressBar) findViewById(R.id.progress_bar);

        mStorageRef = FirebaseStorage.getInstance().getReference("tutores");
        databaseTutor = FirebaseDatabase.getInstance().getReference("tutores");



        mButtonChooseImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFileChooser();
            }
        });


        botao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(senha.getText().toString().equals(confirmarSenha.getText().toString())){
                    tutor = new Tutor();

                    tutor.setNome(nome.getText().toString());
                    tutor.setEmail(email.getText().toString());
                    tutor.setRg(rg.getText().toString());
                    tutor.setDatNasc(dataNasc.getText().toString());
                    tutor.setTelefone(telefone.getText().toString());
                    tutor.setRg(senha.getText().toString());
                    tutor.setDatNasc(confirmarSenha.getText().toString());
                    tutor.setNomeDependente(nomePaciente.getText().toString());
                    tutor.setDataNascDependente(dataNascPaciente.getText().toString());
                    tutor.setTipo(tipoCuidado.getText().toString());
                    tutor.setRua(ruaTxt.getText().toString());
                    tutor.setComplemento(complementoTxt.getText().toString());
                    tutor.setCep(cepTxt.getText().toString());
                    tutor.setCidade(cidadeTxt.getText().toString());





                    cadastrarUsuario();

                }else{
                    Toast.makeText(CadastrarActivity.this, "As senhas não correspondem", Toast.LENGTH_LONG).show();

                }
            }

        });

    }

    private void cadastrarUsuario(){


        String id = databaseTutor.push().getKey();
        String   smImageUrl, snome, semail, srg, sdataNasc, stelefone, ssenha, snomePaciente, sdataNascPaciente, stipoCuidado, sruaTxt, scomplemento, scep, scidade;
        Tutor tutor = new Tutor();
        snome = nome.getText().toString();
        semail = email.getText().toString();
        srg = rg.getText().toString();
        sdataNasc = dataNasc.getText().toString();
        stelefone = telefone.getText().toString();
        ssenha = senha.getText().toString();
        snomePaciente = nomePaciente.getText().toString();
        sdataNascPaciente = dataNascPaciente.getText().toString();
        stipoCuidado = tipoCuidado.getText().toString();
        sruaTxt = ruaTxt.getText().toString();
        scomplemento = complementoTxt.getText().toString();
        scep = cepTxt.getText().toString();
        scidade = cidadeTxt.getText().toString();
        smImageUrl = mImageUri.toString() ;



        tutor.setId(id);
        tutor.setNome(snome);
        tutor.setEmail(semail);
        tutor.setRg(srg);
        tutor.setDatNasc(sdataNasc);
        tutor.setTelefone(stelefone);
        tutor.setSenha(ssenha);
        tutor.setNomeDependente(snomePaciente);
        tutor.setDataNascDependente(sdataNascPaciente);
        tutor.setTipo(stipoCuidado);
        tutor.setRua(sruaTxt);
        tutor.setComplemento(scomplemento);
        tutor.setCep(scep);
        tutor.setCidade(scidade);
        tutor.setImageUrl(smImageUrl);

        databaseTutor.child(id).setValue(tutor);
        autenticacao = ConfiguraFirebase.getFirebaseAutenticacao();
        autenticacao.createUserWithEmailAndPassword(
            tutor.getEmail(), tutor.getSenha()).addOnCompleteListener(CadastrarActivity.this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
               if(task.isSuccessful()){
                   Toast.makeText(CadastrarActivity.this, "Usuário cadastrado com sucesso.", Toast.LENGTH_LONG).show();

                   chamarInserirFoto();

               }else{
                   String erroExcecao = "";

                   try{
                        throw task.getException();

                   }catch (FirebaseAuthWeakPasswordException e){
                            erroExcecao="Digite uma senha mais forte contendo no minimo 8 carac";
                   }catch (FirebaseAuthInvalidCredentialsException e){
                         erroExcecao="O email digitado está invalido";
                   }catch (FirebaseAuthUserCollisionException e){
                        erroExcecao="Email já cadastrado no Cuide";

                   }catch (Exception e){
                       erroExcecao = "Erro ao efetuar Cadastro, tente novamente";
                       e.printStackTrace();
                   }
                   Toast.makeText(CadastrarActivity.this, "Erro " + erroExcecao, Toast.LENGTH_LONG).show();

               }
            }
        });

        if (mImageUri != null){

            StorageReference fileReference = mStorageRef.child(System.currentTimeMillis() + "." + getFileExtension(mImageUri));

            fileReference.putFile(mImageUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            mProgressBar.setProgress(0);
                        }
                    }, 500);

                    Toast.makeText(CadastrarActivity.this,"Foto salva com sucesso", Toast.LENGTH_LONG).show();


                }
            })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(CadastrarActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                            double progress = (100.0 * taskSnapshot.getBytesTransferred()/taskSnapshot.getTotalByteCount());
                            mProgressBar.setProgress((int) progress);
                        }
                    });



        } else{
            Toast.makeText(this, "Nenhum arquivo selacionado", Toast.LENGTH_SHORT).show();

        }






    }


    public void chamarInserirFoto(){
        Intent intent = new Intent(CadastrarActivity.this, Introducao.class);
        startActivity(intent);
        finish();


    }

    private void openFileChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, PICk_IMAGE_REQUEST);


    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == PICk_IMAGE_REQUEST && resultCode == RESULT_OK && data != null
                && data.getData() != null){

            mImageUri = data.getData();

            Picasso.get().load(mImageUri).into(mImageView);





        }
    }

    private String getFileExtension(Uri uri){
        ContentResolver cR = getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton().getSingleton();
        return mime.getExtensionFromMimeType(cR.getType(uri));
    }

    private void uploadFile(){
        if (mImageUri != null){

            StorageReference fileReference = mStorageRef.child(System.currentTimeMillis() + "." + getFileExtension(mImageUri));

            fileReference.putFile(mImageUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            mProgressBar.setProgress(0);
                        }
                    }, 500);

                    Toast.makeText(CadastrarActivity.this,"Foto salva com sucesso", Toast.LENGTH_LONG).show();
                    String uploadId = databaseTutor.push().getKey();
                    databaseTutor.child(uploadId);

                }
            })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(CadastrarActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                            double progress = (100.0 * taskSnapshot.getBytesTransferred()/taskSnapshot.getTotalByteCount());
                            mProgressBar.setProgress((int) progress);
                        }
                    });



        } else{
            Toast.makeText(this, "Nenhum arquivo selacionado", Toast.LENGTH_SHORT).show();

        }



    }


}


