package com.example.aluno.cuide.Activity;

import android.content.Context;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.example.aluno.cuide.R;

import java.util.List;

public class MyAdapter extends PagerAdapter{

    List<Integer> lstImages;
    Context context;
    LayoutInflater layoutInflater;

    public MyAdapter (List<Integer> lstImages, Context context){
        this.lstImages = lstImages;
        this.context = context;
        layoutInflater = LayoutInflater.from(context);

    }


    public int getCount(){

        return lstImages.size();

    }

    public boolean isViewFromObject(View view, Object object){
         return view.equals(object);


    }

    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((LinearLayout)object);
    }

    public Object instantiateItem(ViewGroup container, int position){
            View view = layoutInflater.inflate(R.layout.carditem, container,false);
            ImageView imageView = (ImageView)view.findViewById(R.id.imageView);
            imageView.setImageResource(lstImages.get(position));

            container.addView(view);
            return view;

    }

}
